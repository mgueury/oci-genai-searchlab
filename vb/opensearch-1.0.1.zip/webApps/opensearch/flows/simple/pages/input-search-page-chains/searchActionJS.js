define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils00
) => {
  'use strict';

  class searchActionJS extends ActionChain {

    /**
     * searchActionJS
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.originButton 
     */
    async run(context, { originButton = 'search' }) {
      const { $page, $flow, $application } = context;
      var compartmentId = "ocid1.compartment.oc1..aaaaaaaa4lwvzifc7ccwfv2fthpjys25b4ogazljgqfyk26eh2cnkhjcr6ka"

      $page.variables.originButton = originButton;
      $page.variables.ragResponse = "...";

      if (originButton === "generate") {
        $page.variables.opensearchHit = [];
        let prompt = 'You are a program answering with a simple clear response of one sentence.\n'
          + 'Question: ' + $page.variables.searchText;
        prompt.replaceAll("\"", "'");
        let llmQuestion = {
          "prompts": [ prompt ],
          "maxTokens": 600,
          "temperature": 0,
          "frequencyPenalty": 1,
          "presencePenalty": 0,
          "topP": 0.75,
          "topK": 0,
          "compartmentId": compartmentId,
          "returnLikelihoods": "NONE",
          "isStream": false,
          "servingMode": {
            "modelId": "cohere.command",
            "servingType": "ON_DEMAND"
          }
        };
        const llmRestResult = await Actions.callRest(context, {
          endpoint: 'GenerateText/generateText',
          body: llmQuestion,
        });
        $page.variables.ragResponse = llmRestResult.body.generatedTexts[0][0].text;
        return;
      } else if (originButton === "search") {
        const callRestOpensearchSearchResult = await Actions.callRest(context, {
          endpoint: 'opensearch/search',
          responseType: 'opensearchResponseType',
          responseBodyFormat: 'json',
          uriParams: {
            q: $page.variables.searchText,
          },
        });

        $page.variables.opensearchResponse = callRestOpensearchSearchResult.body;
      }
      else {
        $page.variables.embedText = {
          "inputs": [$page.variables.searchText],
          "servingMode": {
            "servingType": "ON_DEMAND",
            "modelId": "cohere.embed-english-light-v2.0"
          },
          "truncate": "START",
          "compartmentId": compartmentId
        };
        const restResult = await Actions.callRest(context, {
          endpoint: 'EmbedText/get20231130ActionsEmbedText',
          responseBodyFormat: 'json',
          responseType: 'any',
          body: $page.variables.embedText,
        });
        $page.variables.semanticSearch = {
          "size": 10,
          "query": {
            "knn": {
              "cohere_embed": {
                "vector": restResult.body.embeddings[0],
                "k": 10
              }
            }
          }
        };
        const callRestOpensearchSearchResult2 = await Actions.callRest(context, {
          endpoint: 'opensearch/semanticSearch',
          responseBodyFormat: 'json',
          responseType: 'opensearchResponseType',
          body: $page.variables.semanticSearch,
        });

        $page.variables.opensearchResponse = callRestOpensearchSearchResult2.body;
      }
      $page.variables.hitTotal = $page.variables.opensearchResponse.hits.total.value;
      const truncateResult = await $page.functions.TruncateContent($page.variables.opensearchResponse.hits.hits);
      $page.variables.opensearchHit = truncateResult;


      if (originButton === "rag") {
        let prompt = 'You are a program answering with a simple clear response of one sentence.\n'
          + 'In the following text, find the answer of the question in the following documents\n'
          + 'Question: ' + $page.variables.searchText + '\n';
        for ( let res of truncateResult) {
          prompt += '-----\n';
          prompt += res._source.content + '\n';
        }
        prompt.replaceAll("\"", "'");
        let llmQuestion = {
          "prompts": [ prompt ],
          "maxTokens": 600,
          "temperature": 0,
          "frequencyPenalty": 1,
          "presencePenalty": 0,
          "topP": 0.75,
          "topK": 0,
          "compartmentId": compartmentId,
          "returnLikelihoods": "NONE",
          "isStream": false,
          "servingMode": {
            "modelId": "cohere.command",
            "servingType": "ON_DEMAND"
          }
        };
        const llmRestResult = await Actions.callRest(context, {
          endpoint: 'GenerateText/generateText',
          body: llmQuestion,
        });
        $page.variables.ragResponse = llmRestResult.body.generatedTexts[0][0].text;
      }
    }
  }

  return searchActionJS;
});
