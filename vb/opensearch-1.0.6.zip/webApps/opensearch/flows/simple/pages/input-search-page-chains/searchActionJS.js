define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils00
) => {
  'use strict';

  function highlightText(searchValue) {
    if (searchValue !== '') {
      var aElem = document.getElementsByClassName("opensearch-content");
      for (var i = 0; i < aElem.length; i++) {
        const content = aElem[i].innerHTML;
        const highlightedContent = content.replace(
          new RegExp(searchValue, 'gi'),
          '<span class="highlight">$&</span>'
        );
        aElem[i].innerHTML = highlightedContent;
      }
    }
  }

  let compartmentId = "ocid-xxx";

  class searchActionJS extends ActionChain {

    longestCommonSubstring(str1, str2) {
      let n = str1.length;
      let m = str2.length;

      let lcs = [];
      for (let i = 0; i <= n; i++) {
        lcs[i] = [];
        for (let j = 0; j <= m; j++) {
          lcs[i][j] = 0;
        }
      }
      let result = "";
      let max = 0;
      for (let i = 0; i < n; i++) {
        for (let j = 0; j < m; j++) {
          if (str1[i] === str2[j]) {
            lcs[i + 1][j + 1] = lcs[i][j] + 1;
            if (lcs[i + 1][j + 1] > max) {
              max = lcs[i + 1][j + 1];
              result = str1.substring(i - max + 1, i + 1);
            }
          }
        }
      }
      return result;
    }



    highlightCommonSubString(response, hits) {
      hits.forEach((hit, index, array) => {
        console.log("highlightCommonSubString: " + hit._source.content);
        let common = this.longestCommonSubstring(response, hit._source.content);
        if (common.length > 20) {
          highlightText(common);
        }
      });
    }

    async getLlmRequest(prompt) {
      prompt.replaceAll("\"", "'");

      let llmRequest = {
        "compartmentId": compartmentId,
        "servingMode": {
            "modelId": "ocid1.generativeaimodel.oc1.us-chicago-1.amaaaaaask7dceyafhwal37hxwylnpbcncidimbwteff4xha77n5xz4m7p6a",
            "servingType": "ON_DEMAND"
        },
        "inferenceRequest": {
            "prompt": prompt,
            "maxTokens": 600,
            "temperature": 0,
            "frequencyPenalty": 0,
            "presencePenalty": 0,
            "topP": 0.75,
            "topK": 0,
            "isStream": false,
            "stopSequences": [],
            "runtimeType": "COHERE"
        }
      };
      return llmRequest;
    }

    getLlmRequestForQuestion(question) {
      let prompt = 'You are a program answering with a simple clear response of one sentence.\n'
        + 'Question: ' + question;
      return this.getLlmRequest(prompt);
    }

    /**
     * searchActionJS
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.originButton 
     */
    async run(context, { originButton = 'search' }) {
      const { $page, $flow, $application } = context;

      $page.variables.originButton = originButton;
      $page.variables.ragResponse = "...";
      $page.variables.ragDocument = "";
      compartmentId = $application.constants.compartmentId;

      if (originButton === "generate") {
        $page.variables.opensearchHit = [];
        let llmRestResult = await Actions.callRest(context, {
          endpoint: 'GenerateText/generateText',
          body: this.getLlmRequestForQuestion($page.variables.searchText),
        });
        $page.variables.ragResponse = llmRestResult.body.inferenceResponse.generatedTexts[0].text;
        return;
      } else if (originButton === "search") {
        /* 
        const callRestOpensearchSearchResult = await Actions.callRest(context, {
          endpoint: 'opensearch/search',
          responseType: 'opensearchResponseType',
          responseBodyFormat: 'json',
          uriParams: {
            q: $page.variables.searchText,
          },
        });
        */
        let query = {
          "size": 10,
          "query": {
            "query_string": {
              "query": $page.variables.searchText
            }
          },
          "aggs": {
            "unique_vals": {
              "terms": {
                "field": "path.keyword"
              }
            }
          }
        };
        const callRestOpensearchSearchResult = await Actions.callRest(context, {
          endpoint: 'opensearch/semanticSearch',
          responseBodyFormat: 'json',
          responseType: 'opensearchResponseType',
          body: query
        });


        $page.variables.opensearchResponse = callRestOpensearchSearchResult.body;
        setTimeout(function () {
          highlightText($page.variables.searchText);
        }, 200);
      }
      else {
        $page.variables.embedText = {
          "inputs": [$page.variables.searchText],
          "servingMode": {
            "servingType": "ON_DEMAND",
            "modelId": "cohere.embed-english-v3.0"
          },
          "truncate": "START",
          "compartmentId": compartmentId
        };
        const restResult = await Actions.callRest(context, {
          endpoint: 'EmbedText/get20231130ActionsEmbedText',
          responseBodyFormat: 'json',
          responseType: 'any',
          body: $page.variables.embedText,
        });
        $page.variables.semanticSearch = {
          "size": 10,
          "query": {
            "knn": {
              "cohere_embed": {
                "vector": restResult.body.embeddings[0],
                "k": 10
              }
            }
          }
        };
        const callRestOpensearchSearchResult2 = await Actions.callRest(context, {
          endpoint: 'opensearch/semanticSearch',
          responseBodyFormat: 'json',
          responseType: 'opensearchResponseType',
          body: $page.variables.semanticSearch,
        });

        $page.variables.opensearchResponse = callRestOpensearchSearchResult2.body;
      }
      $page.variables.hitTotal = $page.variables.opensearchResponse.hits.total.value;
      const truncateResult = await $page.functions.TruncateContent($page.variables.opensearchResponse.hits.hits);
      $page.variables.opensearchHit = truncateResult;


      if (originButton === "rag") {
        let prompt =
          `You are a person answering questions in a predefined json format based on 3 rules. The question is: "${$page.variables.searchText}". 
To respond to the question, follow the 3 following rules:
1. Answer the question only based on the json documents below
2. If the answer is not found in the content of the documents below, say "I do not find the answer in the documents." 
3. The answer has the following json format: { "found": "Boolean response found in document", "document": "Document where the response is found", "response": "response of the question"}

JSON document

[`;
        var bFirst = true;
        for (let res of truncateResult) {
          if (bFirst) {
            bFirst = false;
          } else {
            prompt += ",";
          }
          prompt +=
            `{ "Document": "${res._source.filename}",
"Context": "",
"Sentence": "${res._source.content}" }`;
        }
        prompt += ']';
        let llmRestResult = await Actions.callRest(context, {
          endpoint: 'GenerateText/generateText',
          body: this.getLlmRequest(prompt),
        });
        let jsonRes = llmRestResult.body.inferenceResponse.generatedTexts[0].text;
        let objRes = { found: false };
        if( jsonRes.indexOf("I do not find the answer in the documents")<0 ) {
          try {
            objRes = JSON.parse(jsonRes);
          } catch(error) {
            // GenAI does not answer with JSON sometimes....
            objRes = { found: true, response: jsonRes, document: "-" };
          }
        }
        let response = "-";
        if (objRes.found) {
          $page.variables.ragResponse = objRes.response;
          if (objRes.document !== "-" ) {
            $page.variables.ragDocument = "Document: " + objRes.document;
          }
          this.highlightCommonSubString(objRes.response, $page.variables.opensearchResponse.hits.hits);
        }
        else {
          let llmRestResult2 = await Actions.callRest(context, {
            endpoint: 'GenerateText/generateText',
            body: this.getLlmRequestForQuestion($page.variables.searchText),
          });
          $page.variables.ragDocument = "I think that: " + llmRestResult2.body.inferenceResponse.generatedTexts[0].text;
          $page.variables.ragResponse = "I do not find the answer in the documents.";
        }
      }
    }
  }

  return searchActionJS;
});
