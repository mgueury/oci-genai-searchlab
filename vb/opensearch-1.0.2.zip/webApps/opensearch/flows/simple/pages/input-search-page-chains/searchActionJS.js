define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils00
) => {
  'use strict';

  const compartmentId = "ocid1.compartment.oc1..aaaaaaaa4lwvzifc7ccwfv2fthpjys25b4ogazljgqfyk26eh2cnkhjcr6ka";

  class searchActionJS extends ActionChain {

     async getLlmRequest( prompt ) {
       prompt.replaceAll("\"", "'");

       let llmRequest = {
          "prompts": [ prompt ],
          "maxTokens": 600,
          "temperature": 0,
          "frequencyPenalty": 1,
          "presencePenalty": 0,
          "topP": 0.75,
          "topK": 0,
          "compartmentId": compartmentId,
          "returnLikelihoods": "NONE",
          "isStream": false,
          "servingMode": {
            "modelId": "cohere.command",
            "servingType": "ON_DEMAND"
          }
        };
        return llmRequest;
    }

    getLlmRequestForQuestion( question ) {
        let prompt = 'You are a program answering with a simple clear response of one sentence.\n'
          + 'Question: ' +  question;
        return this.getLlmRequest( prompt );
    } 

    /**
     * searchActionJS
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.originButton 
     */
    async run(context, { originButton = 'search' }) {
      const { $page, $flow, $application } = context;

      $page.variables.originButton = originButton;
      $page.variables.ragResponse = "...";

      if (originButton === "generate") {
        $page.variables.opensearchHit = [];
        let llmRestResult = await Actions.callRest(context, {
          endpoint: 'GenerateText/generateText',
          body: this.getLlmRequestForQuestion( $page.variables.searchText ),
        });
        $page.variables.ragResponse = llmRestResult.body.generatedTexts[0][0].text;
        return;
      } else if (originButton === "search") {
        const callRestOpensearchSearchResult = await Actions.callRest(context, {
          endpoint: 'opensearch/search',
          responseType: 'opensearchResponseType',
          responseBodyFormat: 'json',
          uriParams: {
            q: $page.variables.searchText,
          },
        });

        $page.variables.opensearchResponse = callRestOpensearchSearchResult.body;
      }
      else {
        $page.variables.embedText = {
          "inputs": [$page.variables.searchText],
          "servingMode": {
            "servingType": "ON_DEMAND",
            "modelId": "cohere.embed-english-light-v2.0"
          },
          "truncate": "START",
          "compartmentId": compartmentId
        };
        const restResult = await Actions.callRest(context, {
          endpoint: 'EmbedText/get20231130ActionsEmbedText',
          responseBodyFormat: 'json',
          responseType: 'any',
          body: $page.variables.embedText,
        });
        $page.variables.semanticSearch = {
          "size": 10,
          "query": {
            "knn": {
              "cohere_embed": {
                "vector": restResult.body.embeddings[0],
                "k": 10
              }
            }
          }
        };
        const callRestOpensearchSearchResult2 = await Actions.callRest(context, {
          endpoint: 'opensearch/semanticSearch',
          responseBodyFormat: 'json',
          responseType: 'opensearchResponseType',
          body: $page.variables.semanticSearch,
        });

        $page.variables.opensearchResponse = callRestOpensearchSearchResult2.body;
      }
      $page.variables.hitTotal = $page.variables.opensearchResponse.hits.total.value;
      const truncateResult = await $page.functions.TruncateContent($page.variables.opensearchResponse.hits.hits);
      $page.variables.opensearchHit = truncateResult;


      if (originButton === "rag") {
        let prompt = 'Answer the question based only on the documents below.\n'
          + 'If the answer is found in the documents below, answer the question.\n'
          + 'If the answer is not found in the documents below, say "I do not find the answer in the documents." \n'
          + 'The question is: "' + $page.variables.searchText + '"\n';
        for ( let res of truncateResult) {
          prompt += '-----\n';
          prompt += res._source.content + '\n';
        }
        let llmRestResult = await Actions.callRest(context, {
          endpoint: 'GenerateText/generateText',
          body: this.getLlmRequest( prompt ),
        });
        let response = llmRestResult.body.generatedTexts[0][0].text;
        if( response.indexOf ('I do not find the answer')>=0 ) {
          let llmRestResult = await Actions.callRest(context, {
             endpoint: 'GenerateText/generateText',
             body: this.getLlmRequestForQuestion( $page.variables.searchText ),
          });
          response = "I do not find the answer in the documents. I think that: " +  llmRestResult.body.generatedTexts[0][0].text;
        } 
        $page.variables.ragResponse = response;  
      }
    }
  }

  return searchActionJS;
});
